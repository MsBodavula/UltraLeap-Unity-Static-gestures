using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap;
using Leap.Unity;
using System.IO;
using Newtonsoft.Json;

public static class Vector3Extensions
{
    public static float[] ToFloatArray(this Vector3 vector)
    {
        return new float[] { vector.x, vector.y, vector.z };
    }
}

public static class QuaternionExtensions
{
    public static float[] ToFloatArray(this Quaternion quaternion)
    {
        return new float[] { quaternion.x, quaternion.y, quaternion.z, quaternion.w };
    }
}

public class DataCollection : MonoBehaviour
{
    public LeapProvider leapProvider;
    public string savePath = "C:/Users/vbodavul/StaticData/";
    private bool isCapturing = false;
    private bool hasCapturedScreenshot = false;
    private List<DataContainer> gestureDataList = new List<DataContainer>();
    private string currentScreenshotPath = ""; // Store the current screenshot path

    void Update()
    {
        // Start capturing data on 'C' key press
        if (Input.GetKeyDown(KeyCode.C))
        {
            isCapturing = true;
            hasCapturedScreenshot = false;
            // Clear the gestureDataList when starting a new capture
            gestureDataList.Clear();

            // Take a screenshot when 'C' key is pressed
            currentScreenshotPath = SaveScreenshot();
            if (!string.IsNullOrEmpty(currentScreenshotPath))
            {
                hasCapturedScreenshot = true;
            }
        }

        // Check if we are capturing data
        if (isCapturing)
        {
            if (leapProvider != null)
            {
                // Get the current frame from the Leap provider
                Frame currentFrame = leapProvider.CurrentFrame;

                // Save the frame data
                SaveFrameData(currentFrame);
            }
            else
            {
                Debug.LogWarning("Leap provider not assigned!");
            }
        }

        // Stop capturing data and save the data to JSON file on 'C' key release
        if (Input.GetKeyUp(KeyCode.C) && isCapturing && hasCapturedScreenshot)
        {
            // Stop capturing data
            isCapturing = false;

            // Save the gesture data to JSON file
            SaveDataToFile();

            Debug.Log("Data saved.");
        }
    }



    private void SaveFrameData(Frame frame)
    {
        // Implement your logic to save the necessary hand tracking data from the Leap Motion frame
        // For demonstration purposes, let's store finger positions and palm position.

        List<Dictionary<string, object>> handDataList = new List<Dictionary<string, object>>();

        foreach (var hand in frame.Hands)
        {
            // Create a dictionary to store hand data
            Dictionary<string, object> handData = new Dictionary<string, object>();

            // Save hand ID, position, and rotation
            handData.Add("HandID", hand.Id);
            handData.Add("HandPosition", hand.PalmPosition.ToFloatArray());
            handData.Add("HandRotation", hand.Basis.rotation.ToFloatArray());

            // Save finger positions
            List<Vector3> fingerPositions = new List<Vector3>();
            foreach (var finger in hand.Fingers)
            {
                fingerPositions.Add(finger.TipPosition);
            }
            handData.Add("FingerPositions", fingerPositions.ConvertAll(vec => vec.ToFloatArray()));

            // Add hand data to the list
            handDataList.Add(handData);
        }

        // Add hand data to the gesture data list
        DataContainer gestureData = new DataContainer
        {
            FrameData = handDataList,
            ScreenshotPath = "" // Empty path as we don't capture a screenshot for gestures
        };

        gestureDataList.Add(gestureData);
    }

    private string SaveScreenshot()
    {
        string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
        string fileName = "Screenshot_" + timestamp + ".png";
        string fullPath = Path.Combine(savePath, fileName);
        ScreenCapture.CaptureScreenshot(fullPath);

        Debug.Log("Screenshot saved at: " + fullPath);

        return fullPath;
    }

    private void SaveDataToFile()
    {
        // Attach the screenshot path to the last captured frame data
        if (gestureDataList.Count > 0)
        {
            gestureDataList[gestureDataList.Count - 1].ScreenshotPath = currentScreenshotPath;
        }

        // Convert the list of gesture data to a JSON string
        string jsonData = JsonConvert.SerializeObject(gestureDataList, Formatting.Indented);

        // Define the path where you want to save the JSON file
        string dataFilePath = @"C:\Users\vbodavul\StaticData\data.json";

        // Save the JSON data to the file
        File.WriteAllText(dataFilePath, jsonData);
    }

    private Dictionary<string, object> GetFrameData(Frame frame)
    {
        // Implement your logic to retrieve the necessary hand tracking data from the Leap Motion frame
        // For example, you can record hand positions, rotations, finger positions, etc.
        // Return the data as a dictionary with keys and corresponding values.

        // Here's an example of what your frame data could look like in the dictionary:
        Dictionary<string, object> frameData = new Dictionary<string, object>();
        frameData.Add("FrameNumber", frame.Id);
        frameData.Add("Timestamp", frame.Timestamp);

        // Add more relevant data as needed...

        return frameData;
    }

    [System.Serializable]
    private class DataContainer
    {
        public List<Dictionary<string, object>> FrameData;
        public string ScreenshotPath;
    }
}
