
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap;
using Leap.Unity;
using System.IO;
using Newtonsoft.Json;

public class NewBehaviourScript : MonoBehaviour
{
    public LeapProvider leapProvider;
    public string savePath = "C:/Users/vbodavul/StaticData/";
    private bool isCapturing = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C))
        {
            // Start capturing data
            isCapturing = true;
        }

        if (isCapturing)
        {
            if (leapProvider != null)
            {
                // Get the current frame from the Leap provider
                Frame currentFrame = leapProvider.CurrentFrame;

                // Save the frame data
                SaveFrameData(currentFrame);

                // Capture and save a screenshot
                string screenshotPath = SaveScreenshot();

                // Combine frame data and image path and save it to a text file
                SaveDataToFile(screenshotPath, currentFrame);

                // Stop capturing data
                isCapturing = false;
            }
            else
            {
                Debug.LogWarning("Leap provider not assigned!");
            }
        }
    }

    private void SaveFrameData(Frame frame)
    {
        // Implement your logic to save the necessary hand tracking data from the Leap Motion frame
        // For example, you can record hand positions, rotations, finger positions, etc.
        // You can store this data in a custom data structure or serialize it to JSON or XML for saving.
        // For demonstration purposes, let's just print the hand count and palm positions.
        Debug.Log("Hand Count: " + frame.Hands.Count);
        foreach (var hand in frame.Hands)
        {
            Debug.Log("Palm Position: " + hand.PalmPosition);
        }
    }

    private string SaveScreenshot()
    {
        string timestamp = System.DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
        string fileName = "Screenshot_" + timestamp + ".png";
        string fullPath = Path.Combine(savePath, fileName);
        ScreenCapture.CaptureScreenshot(fullPath);

        Debug.Log("Screenshot saved at: " + fullPath);

        return fullPath;
    }

    private void SaveDataToFile(string screenshotPath, Frame frame)
    {
        // Create a data container to hold frame data and screenshot path
        DataContainer dataContainer = new DataContainer
        {
            FrameData = GetFrameData(frame),
            ScreenshotPath = screenshotPath
        };

        // Convert the data container to a JSON string
        string jsonData = JsonConvert.SerializeObject(dataContainer, Formatting.Indented);

        // Define the path where you want to save the JSON file
        string dataFilePath = @"C:\Users\vbodavul\StaticData\data.json";

        // Write the JSON data to the file
        File.WriteAllText(dataFilePath, jsonData);

        Debug.Log("Data saved to: " + dataFilePath);
    }

    private Dictionary<string, object> GetFrameData(Frame frame)
    {
        // Implement your logic to retrieve the necessary hand tracking data from the Leap Motion frame
        // For example, you can record hand positions, rotations, finger positions, etc.
        // Return the data as a dictionary with keys and corresponding values.

        // Here's an example of what your frame data could look like in the dictionary:
        Dictionary<string, object> frameData = new Dictionary<string, object>();
        frameData.Add("FrameNumber", frame.Id);
        frameData.Add("Timestamp", frame.Timestamp);

        // Add more relevant data as needed...

        return frameData;
    }

    [System.Serializable]
    private class DataContainer
    {
        public Dictionary<string, object> FrameData;
        public string ScreenshotPath;
    }
}
